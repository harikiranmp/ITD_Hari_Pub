#!/bin/bash 

a=0

while [ $a -le 10 ] ; do
	echo "This is a while loop"
	((a++))
done

